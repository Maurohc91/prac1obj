package pruebas_lombok;

public class AppCursos {


    public static void main(String[] args) {

        Instituto instituto = new Instituto("IES MUTXAMEL");
        //crear cursos
        Curso cursoJava = new Curso("Java", 100);
        Curso cursoPython = new Curso("Python", 70);
        instituto.anyadirCurso(cursoJava);
        instituto.anyadirCurso(cursoPython);
        Estudiante estudiante1 = new Estudiante("Carlos", 20, cursoJava);
        Estudiante estudiante2 = new Estudiante("Ana", 22, cursoPython);
        instituto.anyadirEstudiante(estudiante1);
        instituto.anyadirEstudiante(estudiante2);
        //intento de crear un estudiante con nombre nulo (esto lanza
        //NullPointerException)
        //crear estudiane
        try {
            Estudiante estudianteErroneo = new Estudiante(null);
        } catch (NullPointerException e) {
            System.out.println("Error: No se puede crear un estudiante con nombre nulo.");
        }
        //intento de añadir un estudiante nulo en la lista de estudiantes
        instituto.anyadirEstudiante(null);
        //intento de añadir un curso nulo en la lista de cursos
        instituto.anyadirCurso(null);
        //mostrar cursos
        System.out.println("Cursos disponibles:");
        System.out.println(instituto.getListaCursos());
        //mostrar estudiantes
        System.out.println("Estudiantes registrados:");
        System.out.println(instituto.getListaEstudiantes());
    }
}


