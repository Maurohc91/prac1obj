package pruebas_lombok;

import lombok.*;

@Getter
@Setter
@ToString
//@NoArgsConstructor //constructor vacio
@AllArgsConstructor // constructro con todos
@RequiredArgsConstructor //todo lo que tenga nonull

public class Curso {

    private final String nombre;
    private int horas;

}
