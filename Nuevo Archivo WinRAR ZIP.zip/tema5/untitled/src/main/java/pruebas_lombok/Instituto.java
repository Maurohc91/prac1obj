package pruebas_lombok;

import lombok.*;

import java.util.ArrayList;
import java.util.Objects;

@Getter @Setter @ToString
//@NoArgsConstructor //constructor vacio
@AllArgsConstructor // constructro con todos
@RequiredArgsConstructor //todo lo que tenga nonull
//@Data
//@NonNull

public class Instituto {


    private final String nombre;
    private String poblacion;
    private String direccion;
    private ArrayList<Estudiante> listaEstudiantes = new ArrayList<>();
    private ArrayList<Curso> listaCursos = new ArrayList<>();


    public void anyadirEstudiante( Estudiante estudiante){

      if (estudiante == null){
          System.out.println("No se puede agrerar");
          return;

      }
      listaEstudiantes.add(estudiante);
    }
    public void anyadirCurso(Curso curso) {
        if (curso == null){
            System.out.println("hola");
            return;

        }
        listaCursos.add(curso);
    }

}




//    public void setNombre(@NonNull String nombre) {
//        this.nombre = nombre;
//    }

//    public Instituto(String nombre){
//
//        this.nombre = Objects.requireNonNullElse(nombre, "IES");  //valor comodin POR DEFAULT
////        if(nombre==null){
////            System.out.println("el nombre no puede ser nulo");
////        }else{
////            this.nombre=nombre;
////        }

//    }
