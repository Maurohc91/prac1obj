package org.example;

import java.util.ArrayList;
import java.util.Arrays;

public class Cosas_AR {

    public static void main(String[] args) {

        ArrayList<Integer> listaNums = new ArrayList<>();


        listaNums.add(3);
        listaNums.add(10);
        listaNums.add(90);
        listaNums.add(54);

        System.out.println(listaNums.get(0));
        listaNums.remove(0);
        System.out.println(listaNums.get(0));
        listaNums.remove((Integer) 90);  //para String seria poner "asdfasd"
        System.out.println(listaNums);
        System.out.println(listaNums.indexOf(54)); // te devuelve la posicion
        System.out.println(listaNums.size()); // tamaño del array

        for (int i = 0; i < listaNums.size(); i++) {
            System.out.print(listaNums.get(i));

        }
        for (int nums : listaNums) {
            System.out.println(nums);
        }

        listaNums.set(0, 42);
        System.out.println(listaNums.get(0));

        ArrayList<Integer> listaNums_copia = (ArrayList<Integer>) listaNums.clone();

        listaNums_copia.clear(); // borratodo
        System.out.println(listaNums_copia);

        if (listaNums.contains(42)) {
            System.out.println("la lista cointene 42");
        } else {
            System.out.println("no contiene el 42");
        }
        if (listaNums.isEmpty()) {
            System.out.println("la lsita esta vacia");
        } else {
            System.out.println("la lista no esta vacia");
        }
        listaNums.addAll((Arrays.asList(2, 3, 4, 5)));
        System.out.println(listaNums);

        anyadirVarios(listaNums, 6, 7, 8, 9);
        System.out.println(listaNums);
    }

    public static void anyadirVarios(ArrayList<Integer> lista, Integer... nums) {

        lista.addAll(Arrays.asList(nums));
    }

    ArrayList<String> listaCompra = new ArrayList<>();

//    if(listaCompra.isEmpty()){
//        System.out.println("la lista esta vacia");
//    }else{
//        System.out.println("la lista no esta vacia");
//    }

}