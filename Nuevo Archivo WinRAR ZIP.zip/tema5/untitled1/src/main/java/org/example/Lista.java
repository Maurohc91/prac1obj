package org.example;




import java.sql.SQLOutput;
import java.util.Scanner;

public class Lista {
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {



        System.out.println("nombre?");
        String nombre = entrada.next();
        System.out.println("edad?");
        int edad = entrada.nextInt();
        System.out.println("genero?");
        char genero = entrada.next().charAt(0);
        System.out.println("peso?");
        double peso = entrada.nextDouble();
        System.out.println("altura?");
        double altura = entrada.nextDouble();

        Paciente paciente1 = new Paciente();
        Paciente paciente2 = new Paciente(nombre,edad,genero);
        Paciente paciente3 = new Paciente(nombre,edad,genero,peso,altura);

        paciente1.setNombre("Llados");
        paciente1.setEdad(40);
        paciente1.setGenero('H');
        paciente1.setPeso(120);
        paciente1.setAltura(1.75);

        paciente1.imprimirInfo();
        paciente2.imprimirInfo();
        paciente3.imprimirInfo();

        mostrarMensajeIMC(paciente1);
        mostrarMensajeIMC(paciente2);
        mostrarMensajeIMC(paciente3);

        mayorEdad(paciente1);
        mayorEdad(paciente2);
        mayorEdad(paciente3);



    }

    public static void mostrarMensajeIMC(Paciente paciente){


        int peso = paciente.calcularIMC();

        switch(peso){

            case Paciente.BAJO_PESO:
                System.out.println("El paciente " + paciente.getNombre()+ " está por debajo del peso ideal.");
                break;
            case Paciente.PESO_IDEAL:
                System.out.println("El paciente " + paciente.getNombre()+ " está en su peso ideal.");
                break;
            case Paciente.SOBREPESO:
                System.out.println("El paciente " + paciente.getNombre()+ " está por encima del peso ideal.");
                break;

        }
    }

    public static void mayorEdad(Paciente paciente){

        if(paciente.esMayorDeEdad()){
            System.out.println("el paciente " + paciente.getNombre()+ " es mayor de edad.");
        }else{
            System.out.println("el paciente " + paciente.getNombre()+ " no es mayor de edad.-->" + paciente.getEdad());
        }

    }


}
