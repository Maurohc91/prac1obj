package org.example;

public class Persona {

    private String nombre;
    private String apellido;
    private String DNI;
    private String ciudad;
    private String profesion;
    private char sexo;
    private int edad;

    public String getNombre() {

            return this.nombre;
        }


    public void setNombre(String nombre) {
        if (!nombre.equalsIgnoreCase("Messi")) {
            this.nombre = nombre;
        }
    }
    public String getApellido(){
        return this.apellido;
    }
    public void setApellido(String apellido){
        this.apellido = apellido;
    }
    public String getDNI(){
        return this.DNI;
    }
    public void setDNI(String DNI){
        this.DNI = DNI;
    }
    public char getSexo(){
        return this.sexo;
    }
    public void setSexo(char sexo){
        this.sexo = sexo;
    }
    public int getEdad(){
        return this.edad;
    }
    public void setEdad(int edad){
        this.edad = edad;
    }
    public String getCiudad(){
        return this.ciudad;
    }
    public void setCiudad(String ciudad){
        this.ciudad = ciudad;
    }
    public String getprofesion(){
        return this.profesion;
    }
    public void setProfesion(String profesion){
        this.profesion = profesion;
    }

    public Persona(){



    }

    public Persona(String nombre, String apellido, String DNI,String ciudad,String profesion, char sexo, int edad){

        setNombre(nombre);
        setApellido(apellido);
        setDNI(DNI);
        setCiudad(ciudad);
        setProfesion(profesion);
        setSexo(sexo);
        setEdad(edad);
    }
    public String concatenar(){

        return this.nombre +" " + this.apellido;
    }

    public void mostrarinfo(){

        System.out.println(this.nombre + " " +this.apellido +" "+ this.DNI + " "+ this.ciudad+ " " +this.profesion+ " "+this.sexo + " "+this.edad);

    }
    @Override
    public String toString(){
        return "Persona : [ nombre=" + nombre + " apellido= " + apellido + " dni= " + DNI + " ciudad= " + ciudad + " profesion= " + profesion + " sexo= " + sexo + " edad= " + edad + "]";

    }

}
