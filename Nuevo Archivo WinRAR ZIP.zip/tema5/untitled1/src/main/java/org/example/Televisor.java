package org.example;

public class Televisor {

    private int canal;
    private int volumen;


    public Televisor(){
        this.canal = 5;
        this.volumen = 1;
    }
    public Televisor(int canal, int volumen){
        setCanal(canal);
        setVolumen(volumen);

    }
    public int getVolumen(){
        return this.volumen;
    }
    public void setVolumen(int volumen){
        if (!(volumen > 100 || volumen < 0))
            this.volumen = volumen;
    }
    public int getCanal(){
        return this.canal;
    }
    public void setCanal(int canal){
        if (!(canal > 99 || canal <1))

            this.canal = canal;

    }

    public int subirCanal(){
        return ++this.canal;
    }

    public int bajarCanal(){
        return --this.canal;
    }

}


