package org.example.biblioteca;

import org.example.Equipo;
import org.example.Paciente;
import org.example.Persona;
import org.example.Televisor;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

//        Persona persona1 = new Persona();
//        Persona persona2 = new Persona("Paco", "Ruiz", "1234567A", "Alicante","Fontanero",'H',45 );
//
//        persona1.mostrarinfo();
//        persona2.mostrarinfo();
//
//        persona1.concatenar();
//        persona2.concatenar();
//        System.out.println(persona1.concatenar());
//        System.out.println(persona2.concatenar());

//        System.out.println("La edad de " + persona2.getNombre() + " es " + persona2.getEdad());
//        persona1.setApellido("Sin nombre");
//        System.out.println(persona1.getApellido());
//        persona1.setNombre("Messi");
//        System.out.println(persona1.getNombre());

        Persona persona3 = new Persona("Messi", "Ruiz", "1234567A","Alicante","Fontanero", 'H',45 );
        persona3.mostrarinfo();

        Televisor televisor = new Televisor();


        System.out.println(televisor.getCanal());
        System.out.println(televisor.getVolumen());
        Paciente paciente1 = new Paciente("Luis", 45, 'H',90,1.90);
        paciente1.imprimirInfo();
        Paciente paciente2 = new Paciente();
        paciente2.imprimirInfo();

         Estudiante estudiante1 = new Estudiante("paco");
         Estudiante estudiante2 = new Estudiante("paco", "2ºESO", "noseque@alu.edu.gva.es");

         System.out.println(estudiante1);
         System.out.println(estudiante2);

        if(Estudiante.validarEmail(estudiante2.getEmail())){
            System.out.println("el email es correcto");
        }else{
            System.out.println("correo invalido");
        }

        Editorial editorial1 = new Editorial ("anaya", "ESPAÑA");
        System.out.println(editorial1);

         Libro libro1 = new Libro("el principito", "quevedo",editorial1);
        System.out.println(libro1);
        System.out.println(editorial1);
        Libro libro2 = new Libro ("tiburon", "torres",editorial1);
        System.out.println(libro2);
        System.out.println(editorial1);

        System.out.println(libro1.getLibrosDisponibles());
        Prestamo prestamo1 = libro1.prestar(estudiante2);
        System.out.println(prestamo1);
        System.out.println(libro1);
        System.out.println(libro1.getLibrosDisponibles());


        libro1.devolver(estudiante2);
        System.out.println(libro1);
        System.out.println(Libro.getLibrosDisponibles());
        libro1.devolver(estudiante2);

        libro1.estaDisponible();

        Persona persona1 = new Persona("Marta","Poveda", "21212221D", "Mutxamel", "fontanera", 'M',23);
        Persona persona2 = new Persona("Kikito","Perez", "21213421D", "Mutxamel", "programador", 'H',12);
        Equipo equipo1 = new Equipo("Basta");
        System.out.println(persona1);
        System.out.println(equipo1);
        equipo1.instertarIntegrante(persona1);
        equipo1.instertarIntegrante(persona2);
        System.out.println(equipo1);
        equipo1.borrarIntegrante(persona1);
        System.out.println(equipo1);

    }
}